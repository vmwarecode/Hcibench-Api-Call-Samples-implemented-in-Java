/**
 * ******************************************************
 * Copyright 2020 VMware, Inc.  All Rights Reserved.
 * ******************************************************
 */
package com.vmware.systest.lib.stlib.op.hcibench;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

/**
 * Library class to perform hcibench operations
 * 
 */
public class HcibenchLib {

    private static final Logger log = LoggerFactory.getLogger(HcibenchLib.class);
    private static final SimpleDateFormat dataFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
    protected HciBaseLib hciBaseLib = null;

    public HcibenchLib() {
        this(null);
    }

    public HcibenchLib(String hcibenchIp) {
        super();
        this.hciBaseLib = new HciBaseLib(hcibenchIp);
    }

    /**
     * Generate workload parameter file
     * 
     * @param paramConfig
     * @return boolean
     */
    public boolean generateParam(JsonObject paramConfig) throws Exception {
        try {
            String url = this.hciBaseLib.createRequestUrl(Constants.GENERATE_PARAM);
            HttpResponse response = this.hciBaseLib.sendPostRequest(url, paramConfig);
            JsonObject jsonResponse = this.hciBaseLib.parseResponse(response);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK ||
                    !jsonResponse.get("status").toString().contains("200") ) {
                log.error(Constants.GENERATE_PARAM + " request failed. Response StatusLine: \n" + response.getStatusLine().toString()
                        + " \n Json Response: \n" + jsonResponse.toString());
                return false;
            }
            log.info(Constants.GENERATE_PARAM + "  is executed successfully: \n" + (paramConfig != null ? paramConfig.toString() : ""));
        } catch (Exception e) {
            log.error(Constants.GENERATE_PARAM + "  hit exception: \n", e);
            throw new Exception(Constants.GENERATE_PARAM + "  hit exception: \n" + e);
        }
        return true;
    }

    /**
     * Configure hcibench config file
     * 
     * @param fileConfig
     * @return boolean
     */
    public boolean generateFile(JsonObject fileConfig) throws Exception {
        return performRestApiOp(Constants.GENERATE_FILE, fileConfig);
    }

    /**
     * Validate File
     * 
     * @return boolean
     * @throws Exception
     */
    public boolean validateFile() throws Exception {
        try {
            String url = this.hciBaseLib.createRequestUrl(Constants.VALIDATE_FILE);
            HttpResponse response = this.hciBaseLib.sendPostRequest(url);
            JsonObject jsonResponse = this.hciBaseLib.parseResponse(response);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK
                    || !jsonResponse.get("data").toString().contains(Constants.ALL_CONFIG_VALIDATED)) {
                log.error("validateFile request failed. Response StatusLine: \n" + response.getStatusLine().toString()
                        + " \n Json Response: \n" + jsonResponse.toString());
                return false;
            }
            log.info("validateFile is executed successfully: \n" + jsonResponse.get("data").toString());
        } catch (Exception e) {
            log.error("validateFile hit exception:\n", e);
            throw new Exception("validateFile hit exception:\n  " + e);
        }
        return true;
    }

    /**
     * Run Test
     * 
     * @return boolean
     */
    public boolean runTest() throws Exception {
        return performRestApiOp(Constants.RUN_TEST);
    }

    /**
     * Is test finished
     * 
     * @return boolean
     */
    public boolean isTestFinish() throws Exception {
        try {
            String url = this.hciBaseLib.createRequestUrl(Constants.IS_TEST_FINISH);
            HttpResponse response = this.hciBaseLib.sendPostRequest(url);
            JsonObject jsonResponse = this.hciBaseLib.parseResponse(response);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                log.error("isTestFinish request failed. Response StatusLine: \n" + response.getStatusLine().toString());
                return false;
            }
            if (!jsonResponse.get("data").toString().contains("200")) {
                log.info("Test is not finished yet. Json Response: : \n" + jsonResponse.toString());
                return false;
            }
            log.info("Test is finished: \n");
        } catch (Exception e) {
            log.error("isTestFinish hit exception: \n", e);
            throw new Exception("isTestFinish hit exception:\n  " + e);
        }
        return true;
    }

    /**
     * Read logs from running tests
     * 
     * @return String
     */
    public String readLog() throws Exception {
        String msg = null;
        try {
            String url = this.hciBaseLib.createRequestUrl(Constants.READ_LOG);
            HttpResponse response = this.hciBaseLib.sendGetRequest(url);
            JsonObject jsonResponse = this.hciBaseLib.parseResponse(response);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                log.error("readLog request failed. Response StatusLine: \n" + response.getStatusLine().toString()
                        + " \n Json Response: \n" + jsonResponse.toString());
                return msg;
            }
            msg = jsonResponse.get("data").toString();
            if (msg != null) {
                msg = msg.replace("\\", "");
                log.info("readLog is executed successfully: \n" + msg);
            }
        } catch (Exception e) {
            log.error("readLog hit exception: \n", e);
            throw new Exception("readLog hit exception:\n  " + e);
        }
        return msg;
    }


    /**
     * Kill Test
     * 
     * @return boolean
     */
    public boolean killTest() throws Exception {
        return performRestApiOp(Constants.KILL_TEST);
    }

    /**
     * Cleanup VMs
     * 
     * @return boolean
     */
    public boolean cleanupVms() throws Exception {
        return performRestApiOp(Constants.CLEANUP_VMS);
    }

    /**
     * Perform rest api op
     * 
     * @return boolean
     */
    public boolean performRestApiOp(String restApi) throws Exception {
        return performRestApiOp(restApi, null);
    }

    /**
     * Perform rest api op
     * 
     * @param restApi,
     *            jsonParam
     * @return boolean
     */
    public boolean performRestApiOp(String restApi, JsonObject jsonParam) throws Exception {
        try {
            String url = this.hciBaseLib.createRequestUrl(restApi);
            HttpResponse response = this.hciBaseLib.sendPostRequest(url, jsonParam);
            JsonObject jsonResponse = this.hciBaseLib.parseResponse(response);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                log.error(restApi + " request failed. Response StatusLine: \n" + response.getStatusLine().toString()
                        + " \n Json Response: \n" + jsonResponse.toString());
                return false;
            }
            log.info(restApi + "  is executed successfully: \n" + (jsonParam != null ? jsonParam.toString() : ""));
        } catch (Exception e) {
            log.error(restApi + "  hit exception: \n", e);
            throw new Exception(restApi + "  hit exception: \n" + e);
        }
        return true;
    }

    public static void main(String[] args) throws Exception {

        String hcibenchIp = "10.20.194.144";
        HcibenchLib hcibenchVmOp = new HcibenchLib(hcibenchIp);

        JsonObject paramConfig = new JsonObject();
        paramConfig.addProperty("diskNum", 1);
        paramConfig.addProperty("workSet", 100);
        paramConfig.addProperty("threadNum", 2);
        paramConfig.addProperty("blockSize", "4k");
        paramConfig.addProperty("readPercent", 50);
        paramConfig.addProperty("randomPercent", 50);
        paramConfig.addProperty("ioRate", 999999);
        paramConfig.addProperty("testTime", 60);
        paramConfig.addProperty("warmupTime", 30);
        paramConfig.addProperty("tool", "vdbench");
        //hcibenchVmOp.generateParam(paramConfig);

        JsonObject fileConfig = new JsonObject();
        fileConfig.addProperty("tool", "vdbench");
        fileConfig.addProperty("vcenterIp", "10.145.136.204");
        fileConfig.addProperty("vcenterName", "administrator@vsphere.local");
        fileConfig.addProperty("vcenterPwd", "Admin!23");
        fileConfig.addProperty("dcenterName", "DC45");
        fileConfig.addProperty("clusterName", "Cluster45");
        fileConfig.addProperty("rpName", "");
        fileConfig.addProperty("fdName", "");

        fileConfig.addProperty("networkName", "dvpgVm");
        fileConfig.addProperty("staticEnabled", "false");
        fileConfig.addProperty("staticIpprefix", "");
        fileConfig.addProperty("dstoreName", "vsanDatastore");
        fileConfig.addProperty("storagePolicy", "");
        fileConfig.addProperty("deployHost", "false");
        fileConfig.addProperty("hosts", "");
        fileConfig.addProperty("clearCache", "false");
        fileConfig.addProperty("hostName", "root");
        fileConfig.addProperty("hostPwd", "ca$hc0w");
        fileConfig.addProperty("reuseVM", "true");

        fileConfig.addProperty("easyRun", "false");
        fileConfig.addProperty("workloads", "");

        fileConfig.addProperty("vmPrefix", "hci-vdb");
        fileConfig.addProperty("vmNum", "4");
        fileConfig.addProperty("diskNum", "1");
        fileConfig.addProperty("diskSize", "1");
        fileConfig.addProperty("cpuNum", "4");
        fileConfig.addProperty("ramSize", "8");
        fileConfig.addProperty("filePath", "/opt/automation/vdbench-param-files");

        // fileConfig.addProperty("outPath","");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        fileConfig.addProperty("outPath",
                "HCIBenchTestLogs/" + "hcibench-" + hcibenchIp + "/cust-vc-45-" + dataFormat.format(timestamp));

        fileConfig.addProperty("warmUp", "NONE");
        fileConfig.addProperty("duration", "60");
        fileConfig.addProperty("cleanUp", "false");
        fileConfig.addProperty("selectVdbench", "");
        // hcibenchVmOp.generateFile(fileConfig);

        // hcibenchVmOp.validateFile();

        // hcibenchVmOp.runTest();

        // hcibenchVmOp.isTestFinish();

        // log.info(hcibenchVmOp.readLog());

        // hcibenchVmOp.killTest();

        // hcibenchVmOp.cleanupVms();

    }
}
