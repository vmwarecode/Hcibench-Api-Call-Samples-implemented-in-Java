/**
 * ******************************************************
 * Copyright 2020 VMware, Inc.  All Rights Reserved.
 * ******************************************************
 */
package com.vmware.systest.lib.stlib.op.hcibench;

/**
 * List of Hcibench REST API Constants
 * 
 */
public class Constants {

    // Base url for hcibench API
    public static final String API_BASE_URL = "https://{hcibench_ip}:8443/VMtest";

    public static final String JSON_CONTENT_TYPE = "application/json";
    public static final String CONTENT_TYPE_TAG = "Content-type";
    public static final String RESPONSE_ACCEPT_TAG = "Accept";

    public static final String HCIBENCH_USERNAME = "root";
    public static final String HCIBENCH_PASSWORD = "vmware";

    public static final String GENERATE_PARAM = "/generateParam";
    public static final String GENERATE_FILE = "/generatefile";
    public static final String VALIDATE_FILE = "/validatefile";
    public static final String RUN_TEST = "/runtest";
    public static final String IS_TEST_FINISH = "/istestfinish";
    public static final String READ_LOG = "/readlog";
    public static final String CLEANUP_VMS = "/cleanupvms";
    public static final String KILL_TEST = "/killtest";

    public static final String ALL_CONFIG_VALIDATED =
            "All the config has been validated, please go ahead to kick off testing";

    public static final String HCIBENCH_VM_PATTERN = "(.*)hcibench(.*)";
    public static String TESTING_FINISHED = "Testing Finished";
    public static String TESTING_STARTED = "Started Testing ";

    public static final String DEFAULT_ESX_USERNAME = "root";
    public static final String DEFAULT_ESX_PASSWORD = "ca$hc0w";
}
