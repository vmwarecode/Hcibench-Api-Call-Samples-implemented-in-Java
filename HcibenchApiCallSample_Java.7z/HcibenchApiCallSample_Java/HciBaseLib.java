/**
 * ******************************************************
 * Copyright 2020 VMware, Inc.  All Rights Reserved.
 * ******************************************************
 */
package com.vmware.systest.lib.stlib.op.hcibench;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Base class for hcibench REST API framework
 * 
 */
public class HciBaseLib {

    private String hcibenchIp = null;
    private static final Logger log = LoggerFactory.getLogger(HciBaseLib.class);

    public HciBaseLib() {
        this(null);
    }

    public HciBaseLib(String hcibenchIp) {
        this.hcibenchIp = hcibenchIp;
    }

    public String getHcibenchIp() {
        return hcibenchIp;
    }

    public void setHcibenchIp(String hcibenchIp) {
        this.hcibenchIp = hcibenchIp;
    }

    /**
     * Get httpClient
     * 
     * @return CloseableHttpClient
     */
    private CloseableHttpClient getHttpClient() {
        // By-pass self signed SSL certificate validation
        SSLContext sslContext;
        try {
            sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
        } catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
            throw new RuntimeException(e);
        }
        HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
        SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);
        return HttpClients.custom().setSSLSocketFactory(connectionFactory).build();
    }

    /**
     * Create request url
     * 
     * @param uri
     * @return url
     */
    protected String createRequestUrl(String uri) {
        if (uri != null) {
            uri = Constants.API_BASE_URL + uri;
            if (uri.contains("{hcibench_ip}")) {
                uri = uri.replace("{hcibench_ip}", this.hcibenchIp);
            }
        }
        return uri;
    }

    /**
     * Send get request
     * 
     * @param url
     * @return HttpResponse
     */
    protected HttpResponse sendGetRequest(String url) {
        log.debug("hcibench API get request url : " + url);
        HttpGet get = new HttpGet(url);
        try {
            get.setHeader(new BasicScheme(StandardCharsets.UTF_8).authenticate(
                    new UsernamePasswordCredentials(Constants.HCIBENCH_USERNAME, Constants.HCIBENCH_PASSWORD), get,
                    new BasicHttpContext()));
            return getHttpClient().execute(get);
        } catch (AuthenticationException | IOException e) {
            throw new RuntimeException(e);
        }

    }

    /**
     * Send post request
     * 
     * @param url
     * @return HttpResponse
     */
    protected HttpResponse sendPostRequest(String url) {
        return sendPostRequest(url, null);
    }

    /**
     * Send post request
     * 
     * @param url,
     *            data
     * @return HttpResponse
     */
    protected HttpResponse sendPostRequest(String url, JsonObject data) {
        log.debug("hcibench API post request url : " + url);
        HttpPost post = new HttpPost(url);
        String encoding = Base64.getEncoder()
                .encodeToString((Constants.HCIBENCH_USERNAME + ":" + Constants.HCIBENCH_PASSWORD).getBytes());
        post.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encoding);

        // Construct multipart-formdata
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();

        if (data != null) {
            for (Map.Entry<String, JsonElement> entry : data.entrySet()) {
                // Trim beginning and ending double quotes
                String key = entry.getKey().toString();
                String value = entry.getValue().toString().replaceAll("^\"|\"$", "");
                builder.addTextBody(key, value, ContentType.TEXT_PLAIN);
            }
        }

        HttpEntity multipart = builder.build();
        post.setEntity(multipart);
        log.info("Sending post request : " + post.getRequestLine());
        try {
            return getHttpClient().execute(post);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Parse get/post reponse
     * 
     * @param response
     * @return JsonObject
     */
    protected JsonObject parseResponse(HttpResponse response) {
        HttpEntity entity = response.getEntity();
        InputStream instream;
        try {
            instream = entity.getContent();
        } catch (UnsupportedOperationException | IOException e) {
            throw new RuntimeException(e);
        }
        JsonElement jsonElement = new JsonParser().parse(new InputStreamReader(instream));
        return jsonElement.getAsJsonObject();
    }
}
